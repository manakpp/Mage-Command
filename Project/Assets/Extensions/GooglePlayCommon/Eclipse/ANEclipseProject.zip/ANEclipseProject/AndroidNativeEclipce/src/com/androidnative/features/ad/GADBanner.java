package com.androidnative.features.ad;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.androidnative.AndroidNativeBridge;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

@SuppressLint("NewApi") 
public class GADBanner {

	private int _id;
	private LinearLayout layout = null;
	private AdView adView = null;
	
	
	
	public GADBanner(int x, int y, int size, int id) {
		this(Gravity.TOP, size, id);
		layout.setX(x);
		layout.setY(y);
		
	}
	
	
	public GADBanner(int gravity, int size, int id) {
		
		_id = id;
		
		
		 adView = new AdView(ANMobileAd.GetInstance().GetCurrentActivity());
		 adView.setAdUnitId(ANMobileAd.GetInstance().GetAdUnitID());
	     
		AdSize s;
	    switch(size) {
		     case 1:
		    	 s = AdSize.BANNER;
		    	 break;
		     case 2:
		    	 s = AdSize.SMART_BANNER;
		    	 break;
		     case 3:
		    	 s = AdSize.FULL_BANNER;
		    	 break;
		     case 4:
		    	 s = AdSize.LEADERBOARD;
		    	 break;
		     case 5:
		    	 s = AdSize.MEDIUM_RECTANGLE;
		    	 break;
	    	 default:
	    		 s = AdSize.BANNER;
	     }
	     
	     adView.setAdSize(s);
	    
	     
	    
	   
	     
	    layout = new LinearLayout(ANMobileAd.GetInstance().GetCurrentActivity());
		layout.setGravity(gravity);
		layout.addView(adView, new RelativeLayout.LayoutParams(-2, -2));
		 
	  
		
	  //  adView.loadAd(ANMobileAd.GetInstance().GetAdRequestBuilder().build());
	    AdRequest.Builder builder =  ANMobileAd.GetInstance().GetAdRequestBuilder();
	    AdRequest r = builder.build();
	    
	    Log.d("AndroidNative", "Is Test Device: " +  String.valueOf ( r.isTestDevice(AndroidNativeBridge.GetInstance())   )  );
	    
	    adView.loadAd(r);
	   
	    adView.setAdListener(new BannerAdListner(adView, _id));	
	    adView.setInAppPurchaseListener(new AdInAppListner());
	   
	}
	
	
	
	public void HideAd() {
		if(layout.getParent() != null) {
			ViewGroup vg = (ViewGroup)(layout.getParent());
			vg.removeView(layout);
		}
		
	}
	
	public void ShowAd() {
		if(layout.getParent() == null) {
			ANMobileAd.GetInstance().GetCurrentActivity().addContentView(layout, new RelativeLayout.LayoutParams(-1, -1));
		}
		
	}
	
	
	public void Refresh() {
		adView.loadAd(ANMobileAd.GetInstance().GetAdRequestBuilder().build());
	}
	
	public void Destroy() {
		HideAd();
		
		adView.destroy();
		adView = null;
		layout = null;
	}
}
