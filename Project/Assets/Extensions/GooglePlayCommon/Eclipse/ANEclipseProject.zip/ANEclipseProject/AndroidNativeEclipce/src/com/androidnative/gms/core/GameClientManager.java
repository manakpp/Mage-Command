package com.androidnative.gms.core;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.listeners.appstate.StateDeleteListener;
import com.androidnative.gms.listeners.appstate.StateUpdateListener;
import com.androidnative.gms.listeners.appstate.StatesLoadedListener;
import com.androidnative.gms.listeners.games.AchievementsLoadListner;
import com.androidnative.gms.listeners.games.AchievementsUpdateListner;
import com.androidnative.gms.listeners.games.LeaderBoardScoreLoaded;
import com.androidnative.gms.listeners.games.LeaderBoardsLoadedListener;
import com.androidnative.gms.listeners.games.PlayerResultListner;
import com.androidnative.gms.listeners.games.ScoreSubmitedListner;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.appstate.AppStateStatusCodes;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.unity3d.player.UnityPlayer;

@SuppressLint("NewApi")
public class GameClientManager implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks  {

	protected NewGameHelper mHelper;

	public static final int ACHIEVEMENTS_REQUEST = 20001;
	public static final int LEADER_BOARDS_REQUEST = 20002;

	public static final String CONNECTION_LISTNER_NAME = "GooglePlayConnection";
	public static final String PlAY_SERVICE_LISTNER_NAME = "GooglePlayManager";
	public static final String GOOGLE_CLOUD_LISTNER_NAME = "GoogleCloudManager";


	private static boolean isStarted = false;
	
	public static ArrayList<String> loadedPlayers = new ArrayList<String>();

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------
	
	public void InitPlayService(String scopes) {
		printLog("Creating New GC");
		
		if (!isStarted()) {
			isStarted = true;
			mHelper = new NewGameHelper(this, scopes);
		}
	}
	

	public void sighIn() {
		if(isStarted) {
			if(mHelper != null) {
				mHelper.sighIn();
			}
		}
	}

	// --------------------------------------
	// SHOULD BE REFERED FROM ACTIVITY
	// --------------------------------------

	public void onStop() {
		//mHelper.onStop();
	}



	// --------------------------------------
	// CLOUD METHODS
	// --------------------------------------

	public void listStates() {
		AppStateManager.list(mHelper.getGoogleApiClient()).setResultCallback(new StatesLoadedListener());
	}

	public void resolveState(int stateKey, String resolvedData, String resolvedVersion) {
		
		byte[] stateData = ConvertStringToCloudData(resolvedData);
		AppStateManager.resolve(mHelper.getGoogleApiClient(), stateKey, resolvedVersion, stateData).setResultCallback(new StateUpdateListener());
	}

	public void updateState(int stateKey, String data) {
		CloudUpdateState(stateKey, ConvertStringToCloudData(data));
	}

	private void CloudUpdateState(int stateKey, byte[] stateData) {
		AppStateManager.updateImmediate(mHelper.getGoogleApiClient(), stateKey, stateData).setResultCallback(new StateUpdateListener());
	}

	public void deleteState(int stateKey) {
		AppStateManager.delete(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateDeleteListener());
	}

	public void loadState(int stateKey) {
		AppStateManager.load(mHelper.getGoogleApiClient(), stateKey).setResultCallback(new StateUpdateListener());
	}

	// --------------------------------------
	// GAME SERVICE METHODS
	// --------------------------------------

	
	public void loadConnectedPlayers() {
		Games.Players.loadConnectedPlayers(mHelper.getGoogleApiClient(), true).setResultCallback(new PlayerResultListner());
	}


	// --------------------------------------
	// LEADER_BOARD
	// --------------------------------------

	public void showLeaderBoardsUI() {
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Leaderboards.getAllLeaderboardsIntent(mHelper.getGoogleApiClient()), 
				LEADER_BOARDS_REQUEST);
	}

	public void showLeaderBoardUI(String leaderboardId) {
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Leaderboards.getLeaderboardIntent(mHelper.getGoogleApiClient(), leaderboardId), 
				LEADER_BOARDS_REQUEST);
	}

	public void submitScore(String leaderboardId, int score) {
		Games.Leaderboards.submitScoreImmediate(mHelper.getGoogleApiClient(), leaderboardId, score).setResultCallback(new ScoreSubmitedListner());
	}

	public void loadLeaderBoards() {
		Games.Leaderboards.loadLeaderboardMetadata(mHelper.getGoogleApiClient(), true).setResultCallback(new LeaderBoardsLoadedListener());
	}

	
	public void loadPlayerCenteredScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		  Log.d("AndroidNative", "loadPlayerCenteredScores");
		  Log.d("AndroidNative", Integer.toString(leaderboardCollection) );
		  Log.d("AndroidNative", Integer.toString(span) );
		Games.Leaderboards.loadPlayerCenteredScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	public void loadTopScores(String leaderboardId, int span, int leaderboardCollection, int maxResults) {
		Games.Leaderboards.loadTopScores(mHelper.getGoogleApiClient(), leaderboardId, span, leaderboardCollection, maxResults, true).setResultCallback(new LeaderBoardScoreLoaded(span, leaderboardCollection, leaderboardId));
	}
	
	

	// --------------------------------------
	// ACHIVMENTS
	// --------------------------------------

	public void showAchivmentsUI() {
		
		AndroidNativeBridge.GetInstance().startActivityForResult(
				Games.Achievements.getAchievementsIntent(mHelper.getGoogleApiClient()), 
				ACHIEVEMENTS_REQUEST);
	}
	
	 

	public void reportAchievement(String id) {
		Games.Achievements.unlockImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void incrementAchievement(String id, int numSteps) {
		Games.Achievements.incrementImmediate(mHelper.getGoogleApiClient(), id, numSteps).setResultCallback(new AchievementsUpdateListner());	
	}

	public void revealAchievement(String id) {	
		Games.Achievements.revealImmediate(mHelper.getGoogleApiClient(), id).setResultCallback(new AchievementsUpdateListner());
	}

	public void loadAchivments() {
		Games.Achievements.load(mHelper.getGoogleApiClient(), true).setResultCallback(new AchievementsLoadListner());
	}



	public void signOut() {
		mHelper.sighOut();
	}

	public void showAlert(String title, String message) {
		//mHelper.showAlert(title, message);
	}

	public void showAlert(String message) {
		//mHelper.showAlert(message);
	}

	 /**
     * Called when {@code mGoogleApiClient} is connected.
     */
    @Override
    public void onConnected(Bundle connectionHint) {
        Log.d("AndroidNative", "GoogleApiClient connected");
        
        StringBuilder result = new StringBuilder();
        result.append(Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient()).getPlayerId());
        result.append(AndroidNativeBridge.UNITY_SPLITTER);
        result.append(Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient()).getDisplayName());
        result.append(AndroidNativeBridge.UNITY_SPLITTER);
        result.append(Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient()).getIconImageUrl());
        result.append(AndroidNativeBridge.UNITY_SPLITTER);
        result.append(Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient()).getHiResImageUrl());
        
        UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME, "OnPlayerDataLoaded", result.toString());
        
       
        
        result = new StringBuilder();
		result.append(0);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(0);
	
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
    }

    /**
     * Called when {@code mGoogleApiClient} is disconnected.
     */
    @Override
    public void onConnectionSuspended(int cause) {
    	Log.d("AndroidNative", "onConnectionSuspended");
        Log.d("AndroidNative", "GoogleApiClient connection suspended");
    }
    
    public void onSignInFailed() {
    	Log.d("AndroidNative", "onSignInFailed");
    	 
    	StringBuilder result = new StringBuilder();
 		result.append(13);
 		result.append(AndroidNativeBridge.UNITY_SPLITTER);
 		result.append(0);


 		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
    }


	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		
	    Log.d("AndroidNative", "onConnectionFailed");
	    Log.d("AndroidNative", "Erro code:" +  Integer.toString(arg0.getErrorCode()));
	    Log.d("AndroidNative", "hasResolution: " + String.valueOf(arg0.hasResolution()));
		
		StringBuilder result = new StringBuilder();
		result.append(arg0.getErrorCode());
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		if(arg0.hasResolution()) {
			result.append(1);
		} else {
			result.append(0);
		}
		
		
		
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnConnectionResult", result.toString());
		
		if(arg0.hasResolution()) {
			mHelper.resolveConnection(arg0);
		}
		
		if(arg0.getErrorCode() == AppStateStatusCodes.STATUS_CLIENT_RECONNECT_REQUIRED) {
			mHelper.reconnect();
		}
		
		
	}
	
	public void onActivityResult(int request, int response, Intent data) {
		
		if (request == ACHIEVEMENTS_REQUEST) {
			printLog("ACHIEVEMENTS_REQUEST returned");
		}

		
		mHelper.onActivityResult(request, response, data);
		
	}
	
	
	
	
	
	private void printLog(String msg) {
		Log.d("AndroidNative", "GameClientManager: " + msg);
	}

	public static String ConvertCloudDataToString(byte[] data) {
		String b = "";

		int len = data.length;
		for (int i = 0; i < len; i++) {
			if (i != 0) {
				b += ",";
			}

			b += String.valueOf(data[i]);
		}

		return b;
	}

	public static byte[] ConvertStringToCloudData(String data) {
		
		String[] array = data.split("\\,");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			l.add(Byte.valueOf(b));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	public static boolean isStarted() {
		return isStarted;
	}

}
