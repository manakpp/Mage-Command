package com.androidnative;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.androidnative.billing.core.BillingManager;
import com.androidnative.billing.util.Base64;
import com.androidnative.billing.util.Base64DecoderException;
import com.androidnative.features.AppInfoLoader;
import com.androidnative.features.ImmersiveMode;
import com.androidnative.features.ad.ANMobileAd;
import com.androidnative.features.ad.AdInAppListner;
import com.androidnative.features.analytics.ANGoogleAnalytics;
import com.androidnative.features.common.AddressBookManager;
import com.androidnative.features.notifications.LocalNotificationsController;
import com.androidnative.features.social.common.SocialGate;
import com.androidnative.features.social.instagram.AnInstagram;
import com.androidnative.features.social.twitter.ANTwitter;
import com.androidnative.gcm.ANCloudMessageService;
import com.androidnative.gms.core.GameClientManager;
import com.androidnative.popups.PopUpsManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.unity3d.player.UnityPlayerActivity;

@SuppressLint("NewApi")
public class AndroidNativeBridge extends UnityPlayerActivity {
	
	private static AndroidNativeBridge inst = null;
	private static BillingManager billing = null;
	private static GameClientManager _playService = null;

	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_EOF = "endofline";

	private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
	private FileOutputStream fos;
	
	/**
	 * Tag used on log messages.
	 */
	public static final String TAG = "AndroidNative";

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		inst = this;
	}

	public static AndroidNativeBridge GetInstance() {
		return inst;
	}

	// --------------------------------------
	// Override
	// --------------------------------------

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		try {
			try {
	
				if (billing != null) {
					billing.handleActivityResult(requestCode, resultCode, data);
				}
	
				if (GameClientManager.isStarted()) {
					GetPlayServiceManager().onActivityResult(requestCode, resultCode, data);
				}
	
				
	
			} catch (Exception ex) {
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative", ex.getMessage());
		}

	}

	@Override
	public void onNewIntent(Intent intent) {

		
		Log.d("AndroidNative", "onNewIntent: ");
		super.onNewIntent(intent);

		try {
			try {
				ANTwitter.GetInstance().SetIntent(intent);
			} catch (Throwable ex) {
				Log.d("AndroidNative", "onNewIntent has failed");
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "FB onNewIntent has failed");
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	
		try {
			if (billing != null) {
				billing.dispose();
			}
			billing = null;
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "FB onNewIntent has failed");
		}
	}


	
	@Override
	protected void onStop() {
		super.onStop();
		try {
		
			
			if (GameClientManager.isStarted()) {
				GetPlayServiceManager().onStop();
			}
	
			ANGoogleAnalytics.GetInstance().activityStop();
		
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", ex.getMessage());
		}

	}

	@Override
	public void onWindowFocusChanged(boolean arg0) {
		super.onWindowFocusChanged(arg0);
		
		try {
		
			ImmersiveMode.onWindowFocusChanged(arg0);
		
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "FB onNewIntent has failed");
		}
	}
	
	// --------------------------------------
	// Internal API
	// --------------------------------------
	


	// --------------------------------------
	// Google Cloud
	// --------------------------------------

	public void listStates() {
		GetPlayServiceManager().listStates();
	}

	public void updateState(String stateKey, String data) {
		GetPlayServiceManager().updateState(Integer.parseInt(stateKey), data);
	}

	public void deleteState(String stateKey) {
		GetPlayServiceManager().deleteState(Integer.parseInt(stateKey));
	}

	public void loadState(String stateKey) {
		GetPlayServiceManager().loadState(Integer.parseInt(stateKey));
	}

	public void resolveState(String stateKey, String resolvedData,
			String resolvedVersion) {
		GetPlayServiceManager().resolveState(Integer.parseInt(stateKey), resolvedData,
				resolvedVersion);
	}

	// --------------------------------------
	// Google Cloud Message
	// --------------------------------------

	public void GCMRgisterDevice(String senderId) {
		ANCloudMessageService.GetInstance().registerDevice(senderId);
	}

	
	public void GCMLoadLastMessage() {
		ANCloudMessageService.GetInstance().LoadLastMessage();
	}
	// --------------------------------------
	// Google Play Services
	// --------------------------------------

	public void playServiceInit(String scopes) {
		GetPlayServiceManager().InitPlayService(scopes);
	}

	public void playServiceConnect() {
		GetPlayServiceManager().sighIn();
	}

	public void playServiceDisconnect() {
		GetPlayServiceManager().signOut();
	}

	public void showAchivments() {
		Log.d("AndroidNative", "showAchivments: ");
		GetPlayServiceManager().showAchivmentsUI();
	}

	public void showLeaderBoards() {
		GetPlayServiceManager().showLeaderBoardsUI();
	}

	public void showLeaderBoard(String leaderboardName) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		showLeaderBoardById(leaderboardId);
	}

	public void showLeaderBoardById(String leaderboardId) {
		GetPlayServiceManager().showLeaderBoardUI(leaderboardId);
	}

	public void loadConnectedPlayers() {
		GetPlayServiceManager().loadConnectedPlayers();
	}

	public void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public void submitScoreById(String leaderboardId, String score) {
		GetPlayServiceManager().submitScore(leaderboardId, Integer.parseInt(score));
	}

	public void loadLeaderBoards() {
		GetPlayServiceManager().loadLeaderBoards();
	}

	public void loadPlayerCenteredScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		GetPlayServiceManager().loadPlayerCenteredScores(leaderboardId,
				Integer.parseInt(span),
				Integer.parseInt(leaderboardCollection),
				Integer.parseInt(maxResults));
	}

	public void loadTopScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		GetPlayServiceManager().loadTopScores(leaderboardId, Integer.parseInt(span),
				Integer.parseInt(leaderboardCollection),
				Integer.parseInt(maxResults));
	}

	public void reportAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public void reportAchievementById(String achievementId) {
		GetPlayServiceManager().reportAchievement(achievementId);
	}

	public void revealAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		revealAchievementById(achievementId);
	}

	public void revealAchievementById(String achievementId) {
		GetPlayServiceManager().revealAchievement(achievementId);
	}

	public void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public void incrementAchievementById(String achievementId, String numsteps) {
		GetPlayServiceManager().incrementAchievement(achievementId,
				Integer.parseInt(numsteps));
	}

	public void loadAchivments() {
		GetPlayServiceManager().loadAchivments();
	}

	// --------------------------------------
	// BILLING
	// --------------------------------------

	public void connectToBilling(String ids, String base64EncodedPublicKey) {
		billing = new BillingManager(this);

		ArrayList<String> products = new ArrayList<String>();
		String[] result = ids.split(",");

		for (String id : result) {
			products.add(id);
		}

		billing.connect(products, base64EncodedPublicKey);
	}

	public void retrieveProducDetails() {
		billing.retrieveProducDetails();
	}

	public void consume(String SKU) {
		billing.consume(SKU);
	}

	public void purchase(String SKU, String developerPayload) {
		billing.purchase(SKU, developerPayload);
	}

	// --------------------------------------
	// MESSAGING
	// --------------------------------------

	public void ShowMessage(String title, String message, String ok) {
		PopUpsManager.ShowMessage(title, message, ok);
	}

	public void showDialog(String title, String message, String yes, String no) {
		PopUpsManager.ShowDialog(title, message, yes, no);
	}

	public void ShowRateDialog(String title, String message, String yes,
			String laiter, String no, String url) {
		PopUpsManager.ShowRateDialog(title, message, yes, laiter, no, url);
	}
	
	private static ProgressDialog progress = null;
	public void ShowPreloader(String title, String message) {
		Log.d("AndroidNative", "ShowPreloader: ");
		
		progress = new ProgressDialog(this);
		progress.setTitle(title);
		progress.setMessage(message);
		progress.show();
		progress.setCancelable(false);
		
	}
	
	public void HidePreloader() {
		Log.d("AndroidNative", "HidePreloader: ");
		if(progress != null) {
			progress.hide();
		}
	}

	// --------------------------------------
	// Google AD
	// --------------------------------------
	
	public void InitMobileAd(String id) {
		ANMobileAd.GetInstance().Init(id, this);
	}

	public void ChangeBannersUnitID(String id) {
		ANMobileAd.GetInstance().ChangeBannersUnitID(id);
	}

	public void ChangeInterstisialsUnitID(String id) {
		ANMobileAd.GetInstance().ChangeInterstisialsUnitID(id);
	}

	public void AddKeyword(String keyword) {
		ANMobileAd.GetInstance().AddKeyword(keyword);
	}

	public void AddTestDevice(String deviceId) {
		ANMobileAd.GetInstance().AddTestDevice(deviceId);
	}

	public void SetGender(String gender) {
		ANMobileAd.GetInstance().SetGender(Integer.parseInt(gender));
	}
	
	public void SetBirthday(String year, String month, String day) {
		ANMobileAd.GetInstance().SetBirthday(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
	}
	
	public void TagForChildDirectedTreatment(String tagForChildDirectedTreatment) {
		int b = Integer.parseInt(tagForChildDirectedTreatment);
		if(b == 1) {
			ANMobileAd.GetInstance().TagForChildDirectedTreatment(true);
		} else {
			ANMobileAd.GetInstance().TagForChildDirectedTreatment(false);
		}
		
	}

	public void CreateBannerAd(String gravity, String size, String id) {
		ANMobileAd.GetInstance().CreateBannerAd(Integer.parseInt(gravity),
				Integer.parseInt(size), Integer.parseInt(id));
	}

	public void CreateBannerAdPos(String x, String y, String size, String id) {
		ANMobileAd.GetInstance().CreateBannerAd(Integer.parseInt(x),
				Integer.parseInt(y), Integer.parseInt(size),
				Integer.parseInt(id));
	}

	public void HideAd(String id) {
		ANMobileAd.GetInstance().HideAd(Integer.parseInt(id));
	}

	public void ShowAd(String id) {
		ANMobileAd.GetInstance().ShowAd(Integer.parseInt(id));
	}

	public void RefreshAd(String id) {
		ANMobileAd.GetInstance().Refresh(Integer.parseInt(id));
	}

	public void DestroyBanner(String id) {
		ANMobileAd.GetInstance().DestroyBanner(Integer.parseInt(id));
	}

	public void StartInterstitialAd() {
		ANMobileAd.GetInstance().StartInterstitialAd();
	}

	public void LoadInterstitialAd() {
		ANMobileAd.GetInstance().LoadInterstitialAd();
	}

	public void ShowInterstitialAd() {
		ANMobileAd.GetInstance().ShowInterstitialAd();
	}
	
	public void RecordAdInAppPurchasResolution(String res) {
		AdInAppListner.RecordAdInAppPurchasResolution(Integer.parseInt(res));
	}

	// --------------------------------------
	// OTHER FEATURES
	// --------------------------------------

	public void enableImmersiveMode() {
		ImmersiveMode.enableImmersiveMode();
		
	}
	
	public void loadAddressBook() {
		AddressBookManager.GetInstance().load();
	}

	public void ScheduleLocalNotification(String title, String message, String seconds) {
		int sec = Integer.parseInt(seconds);
		LocalNotificationsController.GetInstance().scheduleNotification(title, message, sec);
	}
	

	public void ShowToastNotification(String text, String duration) {
		Context context = getApplicationContext();

		Toast toast = Toast.makeText(context, text, Integer.parseInt(duration));
		toast.show();
	}
	
	public void LoadPackageInfo() {
		AppInfoLoader.LoadPackageInfo();
	}

	// --------------------------------------
	// Analytics
	// --------------------------------------

	public void startAnalyticsTracking() {
		ANGoogleAnalytics.GetInstance().startAnalyticsTracking(this);
	}

	public void SetTrackerID(String trackingID) {
		ANGoogleAnalytics.GetInstance().SetTracker(trackingID);
	}

	public void SendView(String appScreen) {
		ANGoogleAnalytics.GetInstance().SendView(appScreen);
	}

	public void SendView() {
		ANGoogleAnalytics.GetInstance().SendView();
	}

	public void SendEvent(String category, String action, String label,
			String value) {
		ANGoogleAnalytics.GetInstance().sendEvent(category, action, label,
				value);
	}

	public void SendEvent(String category, String action, String label,
			String value, String key, String val) {
		ANGoogleAnalytics.GetInstance().sendEvent(category, action, label,
				value, key, val);
	}

	public void SetKey(String key, String value) {
		ANGoogleAnalytics.GetInstance().setKey(key, value);
	}

	public void ClearKey(String key) {
		ANGoogleAnalytics.GetInstance().clearKey(key);
	}

	public void SendTiming(String category, String intervalInMilliseconds,
			String name, String label) {
		ANGoogleAnalytics.GetInstance().sendTiming(category,
				intervalInMilliseconds, name, label);
	}

	public void CreateTransaction(String transactionId, String affiliation,
			String revenue, String tax, String shipping, String currencyCode) {
		ANGoogleAnalytics.GetInstance().CreateTransaction(transactionId,
				affiliation, revenue, tax, shipping, currencyCode);
	}

	public void CreateItem(String transactionId, String name, String sku,
			String category, String price, String quantity, String currencyCode) {
		ANGoogleAnalytics.GetInstance().CreateItem(transactionId, name, sku,
				category, price, quantity, currencyCode);
	}

	public void SetLogLevel(String lvl) {
		ANGoogleAnalytics.GetInstance().SetLogLevel(Integer.parseInt(lvl));
	}

	public void SetDryRun(String mode) {

		boolean m = false;
		if (mode.equals("true")) {
			m = true;
		} else {
			m = false;
		}
		ANGoogleAnalytics.GetInstance().setDryRun(m);
	}
	
	// --------------------------------------
	// Social
	// --------------------------------------
	
	public void StartShareIntent(String caption, String message, String subject, String filters) {
		SocialGate.Share(caption, message, subject, filters);
	}
	
	public void StartShareIntentMedia(String caption, String message, String subject, String media, String filters) {
		SocialGate.Share(caption, message, subject, media, filters);
	}


	// --------------------------------------
	// Twitter
	// --------------------------------------

	public void TwitterInit(String consumer_key, String consumer_secret) {
		ANTwitter.GetInstance().Init(consumer_key, consumer_secret, this);
	}

	public void AuthificateUser() {
		ANTwitter.GetInstance().AuthificateUser();
	}

	public void LoadUserData() {
		ANTwitter.GetInstance().LoadUserData();
	}

	public void TwitterPost(String status) {
		ANTwitter.GetInstance().Twitt(status);
	}

	public void TwitterPostWithImage(String status, String data)
			throws IOException, Base64DecoderException {
		Log.d("AndroidNative", "TwitterPostWithImage: ");
		byte[] byteArray = Base64.decode(data);

		File tempFile;
		tempFile = new File(this.getCacheDir(), "twitter_post_image");
		fos = new FileOutputStream(tempFile);
		fos.write(byteArray);

		ANTwitter.GetInstance().Twitt(status, tempFile);
		

	}

	public void LogoutFromTwitter() {
		ANTwitter.GetInstance().logoutFromTwitter();
	}

	// --------------------------------------
	// Instagram
	// --------------------------------------

	public void InstagramPostImage(String data, String caption) {
		AnInstagram.Share(data, caption);
	}

	/**
	 * Check the device to make sure it has the Google Play Services APK. If it
	 * doesn't, display a dialog that allows users to download the APK from the
	 * Google Play Store or enable it in the device's system settings.
	 */
	public boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil
				.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this,
						PLAY_SERVICES_RESOLUTION_REQUEST).show();
			} else {
				Log.i("AndroidNative", "This device is not supported.");
				finish();
			}
			return false;
		}
		return true;
	}



	// --------------------------------------
	// Private Methods
	// --------------------------------------
	
	private GameClientManager GetPlayServiceManager() {
		if(_playService == null) {
			_playService =  new GameClientManager();
		}
		
		return _playService;
	}

	private String getStringResourceByName(String aString) {
		String packageName = getPackageName();
		int resId = getResources()
				.getIdentifier(aString, "string", packageName);
		return getString(resId);
	}

}
